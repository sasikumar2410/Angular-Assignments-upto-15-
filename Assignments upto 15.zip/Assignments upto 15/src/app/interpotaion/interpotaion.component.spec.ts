import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InterpotaionComponent } from './interpotaion.component';

describe('InterpotaionComponent', () => {
  let component: InterpotaionComponent;
  let fixture: ComponentFixture<InterpotaionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ InterpotaionComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(InterpotaionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
