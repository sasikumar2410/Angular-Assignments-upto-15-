import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'interpotaion',
  templateUrl: './interpotaion.component.html',
  styleUrls: ['./interpotaion.component.css']
})
export class InterpotaionComponent {


    name:string = 'sasi kumar';
    getEmployeeInfo(){
      return `Inside the function: ${this.name}`
    }
  }
  


