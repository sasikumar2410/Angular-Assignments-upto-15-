import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-two-binding',
  templateUrl: './two-binding.component.html',
  styleUrls: ['./two-binding.component.css']
})
export class TwoBindingComponent  {

  name:string ='sasi kumar';
  age:number = 20;
 

}

