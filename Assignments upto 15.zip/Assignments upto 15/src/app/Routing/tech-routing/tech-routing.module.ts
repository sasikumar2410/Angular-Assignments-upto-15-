import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdvjavaComponent } from 'src/app/advjava/advjava.component';
import { AdvwebComponent } from 'src/app/advweb/advweb.component';
import { CorejavaComponent } from 'src/app/corejava/corejava.component';
import { CorewebComponent } from 'src/app/coreweb/coreweb.component';
import { JavaComponent } from 'src/app/java/java.component';
import { ProductComponent } from 'src/app/product/product.component';
import { ReactFormComponent } from 'src/app/react-form/react-form.component';
import { ProductService } from 'src/app/services/product.service';
import { TempDrivenFormComponent } from 'src/app/temp-driven-form/temp-driven-form.component';
import { WebComponent } from 'src/app/web/web.component';

const routes:Routes = [
  {path:'web', component:WebComponent, 
  children:[
    {path:'coreweb', component:CorewebComponent },
    {path:'advweb', component:AdvwebComponent}
   ] },
  {path:'java', component:JavaComponent,
   children:[
    {path:'corejava', component:CorejavaComponent },
    {path:'advjava', component:AdvjavaComponent}
   ]
 },
 {
   path:'product',component:ProductComponent,
 },
 {
   path:'react-form',component:ReactFormComponent,
 },
 {
   path:'temp-driven-form',component:TempDrivenFormComponent,
 }
]
@NgModule({
  declarations: [],
  imports: [
    CommonModule, RouterModule.forRoot(routes)
  ],
  exports:[RouterModule]
})
export class TechRoutingModule { }
export const routingComponents = [WebComponent,JavaComponent,ProductComponent,ReactFormComponent,TempDrivenFormComponent]

