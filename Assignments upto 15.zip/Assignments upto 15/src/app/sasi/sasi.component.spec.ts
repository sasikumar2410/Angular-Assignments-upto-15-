import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SasiComponent } from './sasi.component';

describe('SasiComponent', () => {
  let component: SasiComponent;
  let fixture: ComponentFixture<SasiComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SasiComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SasiComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
