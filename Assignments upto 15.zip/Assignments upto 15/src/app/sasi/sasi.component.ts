import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'sasi',
  templateUrl: './sasi.component.html',
  styleUrls: ['./sasi.component.css']
})
export class SasiComponent implements OnInit {

  constructor() {}

  ngOnInit(): void {
  }
 
 customer={
  name:'sasi',
  age:20,
  truth: true,
  array: [10, 20, 30, 40],
  numAndString:  [1, 'Sasikumar'],
  allType: true
 }
  
} 