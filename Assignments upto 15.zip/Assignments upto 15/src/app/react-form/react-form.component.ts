import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-react-form',
  templateUrl: './react-form.component.html',
  styleUrls: ['./react-form.component.css']
})
export class ReactFormComponent  {
   /**
    * Normal Form
    */
  // productForm = new FormGroup({
  //   productName: new FormControl('', [])
  // })

  // submitData() {
  //   console.log(this.productForm)
  //   console.log(this.productForm.value)

  // }

   /**
    * Validation form without using builder
    */
  //  productForm = new FormGroup({
  //   productName: new FormControl('', [
  //     Validators.required,
  //     Validators.pattern('^[a-zA-z]{5,9}$')
  //   ])
  // })
  // submitData() {
  //   console.log(this.productForm)
  //   console.log(this.productForm.value)

  // }
  // /**
  //  *  Validation form with using builder
  //  */
  //  constructor(private formBuilder:FormBuilder){}
  //  productForm = this.formBuilder.group({
  //    productName: ['', [Validators.required, Validators.pattern('^[a-zA-z]{5,9}$')]]
  //  })
 
  //  submitData() {
  //    console.log(this.productForm)
  //    console.log(this.productForm.value)
 
  //  }

  /**
   * Nested Data Assignment 15
   */
   constructor(private formBuilder:FormBuilder){}
   productForm = this.formBuilder.group({
     productName: ['', [Validators.required, Validators.pattern('^[a-zA-z]{5,9}$')]],
     address:this.formBuilder.group({
      city:['', [Validators.required, Validators.pattern('^[a-zA-z]{5,15}$')]],
      postalcode:new FormControl('',[Validators.required, Validators.pattern('^[0-9]{6,6}$')])
    })
   })
   submitData() {
       console.log(this.productForm)
       console.log(this.productForm.value)
   }
}
